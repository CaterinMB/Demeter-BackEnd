// import { DataTypes } from "sequelize";
// import { sequelize } from "../db/dataBase.js";

// export const shoppingDetailAndSupplies = sequelize.define('ShoppingDetails', {

//     ID_ShoppingDetailAndSupplies: {
//         type: DataTypes.INTEGER, 
//         primaryKey: true, 
//         autoIncrement: true
//     }
// }, {
//     timestamps: false
// });
